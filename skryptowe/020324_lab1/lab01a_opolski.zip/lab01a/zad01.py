# app01 
# Podaj z klawiatury dwie liczby pod zmienne a oraz b (funkcja input()).
# Następnie dodaj te dwie liczby i wyświetl wynik
# Zakładamy, że podajemy liczby całkowite lub zmiennoprzecinkowe (nie sprawdzamy tego)

a = int(input("Podaj pierwsza liczbe: "))
b = int(input("Podaj druga liczbe: "))
c = a + b
print(c)
