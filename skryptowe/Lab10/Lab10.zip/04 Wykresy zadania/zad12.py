# Zdefiniuj funkcję do tworzenia wykresu.
# Podaj jako parametr wejściowy dowolny wielomian w ostaci tekstu, oraz granice x oraz y w postaci listy od i do.
# def fun('1/(x+2)',[-5,5],[-10,10])