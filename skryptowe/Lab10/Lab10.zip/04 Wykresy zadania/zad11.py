# Mamy dane zachorowań na COVID w Polsce
# https://www.gov.pl/attachment/7152d6ee-4519-4f02-98e4-38376c3705eb
# Narysować wykres z legendą z pełną nazwą województwa
# i procentową ilością przypadków w stosunku do całego kraju
# i procentową ilością zgonów w stosunku do zgonów w całym kraju

