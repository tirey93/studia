# 11. (zadanie nieobowiązkowe)
# Utwórz tabelę California w bazie test.db (za pomocą narzędzi graficznych) z kolumnami
# id (klucz podstawowy autonumerowany),
# place,
# population,
# pct_under_18,
# pct_between_18_64,
# pct_over 64,
# male_female_ratio

# Zapisz wszystkie wiersze z pliku california.txt do tabeli California
# i podaj liczbę wszystkich osób.
# Wykorzystaj do tego polecenie języka sql 'select sum(population) from California'