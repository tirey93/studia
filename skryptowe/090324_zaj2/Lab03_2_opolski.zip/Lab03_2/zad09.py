# zdanie dodatkowe dla chętnych - nieobowiązkowe
# ----------------------------------------------
# 9. Dwie osoby grają w oczko dwoma kostkami (do 21). 
#    Najpierw rzuca kilka razy pierwsza osoba, aż do decyzji o przerwaniu dalszych rzutów 
#    w danej partii lub przekroczeniu wartości 21 (automatyczna przegrana), a następnie rzuca druga osoba.
#   Po każdej partii:
# - wyświetlamy informację o wygranej jednej z osób, remisie lub przegranej obu. Podajemy wyrzucony wynik każdej z osób.
# Po zakończeniu partii:
# - liczymy ile zabrakło każdej z osób osobno do 21 (sumujemy ilość gier) - liczymy średnią,
# - liczymy ile było było wartości 21 dla kazdej z osób (sumujemy ilość gier),
# - liczymy o ile przekroczyła każda z osób wartość 21 (sumujemy ilość gier przegranych) - liczymy średnią.

# Aby skasowac historię rzutów danej osoby należy wyczyścić ekran consoli poleceniem:
# import os
# os.system('cls')